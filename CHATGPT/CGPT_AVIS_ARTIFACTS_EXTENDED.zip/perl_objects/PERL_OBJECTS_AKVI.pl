/* AVIS ARTIFACT STUB
 * FOLDER: perl_objects
 * INDEX: 1
 */
sub avis_stub { return 1; }
