/* AVIS ARTIFACT STUB
 * FOLDER: perl_objects
 * INDEX: 4
 */
sub avis_stub { return 1; }
