/* AVIS ARTIFACT STUB
 * FOLDER: perl_objects
 * INDEX: 5
 */
sub avis_stub { return 1; }
