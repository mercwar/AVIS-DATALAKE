/* AVIS ARTIFACT STUB
 * FOLDER: c_objects
 * INDEX: 1
 */
int AVIS_Stub(){return 0;}
