/* AVIS ARTIFACT STUB
 * FOLDER: c_objects
 * INDEX: 9
 */
int AVIS_Stub(){return 0;}
