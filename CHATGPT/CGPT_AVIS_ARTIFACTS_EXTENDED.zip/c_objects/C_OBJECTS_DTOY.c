/* AVIS ARTIFACT STUB
 * FOLDER: c_objects
 * INDEX: 8
 */
int AVIS_Stub(){return 0;}
