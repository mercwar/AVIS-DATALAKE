/* AVIS ARTIFACT STUB
 * FOLDER: c_objects
 * INDEX: 2
 */
int AVIS_Stub(){return 0;}
