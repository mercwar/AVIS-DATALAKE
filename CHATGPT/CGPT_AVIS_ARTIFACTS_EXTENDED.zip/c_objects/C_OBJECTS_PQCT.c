/* AVIS ARTIFACT STUB
 * FOLDER: c_objects
 * INDEX: 10
 */
int AVIS_Stub(){return 0;}
