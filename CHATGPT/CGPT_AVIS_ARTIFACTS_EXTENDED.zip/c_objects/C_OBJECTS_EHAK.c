/* AVIS ARTIFACT STUB
 * FOLDER: c_objects
 * INDEX: 7
 */
int AVIS_Stub(){return 0;}
