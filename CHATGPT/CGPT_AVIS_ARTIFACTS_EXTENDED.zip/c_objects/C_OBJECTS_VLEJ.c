/* AVIS ARTIFACT STUB
 * FOLDER: c_objects
 * INDEX: 0
 */
int AVIS_Stub(){return 0;}
