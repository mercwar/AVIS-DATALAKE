/* AVIS ARTIFACT STUB
 * FOLDER: c_objects
 * INDEX: 6
 */
int AVIS_Stub(){return 0;}
